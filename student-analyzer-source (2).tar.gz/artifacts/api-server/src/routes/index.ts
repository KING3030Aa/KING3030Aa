import { Router, type IRouter } from "express";
import healthRouter from "./health";
import authRouter from "./auth";
import examsRouter from "./exams";

const router: IRouter = Router();

router.use(healthRouter);
router.use(authRouter);
router.use(examsRouter);

export default router;
