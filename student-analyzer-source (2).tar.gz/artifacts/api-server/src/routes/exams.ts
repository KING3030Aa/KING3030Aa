import { Router } from "express";
import { db } from "@workspace/db";
import { examsTable } from "@workspace/db/schema";
import { eq } from "drizzle-orm";

const examsRouter = Router();

examsRouter.get("/exams", async (req, res) => {
  if (!req.isAuthenticated()) return res.status(401).json({ error: "Unauthorized" });
  const userId = req.user!.id;
  const rows = await db.select().from(examsTable).where(eq(examsTable.userId, userId));
  const exams = rows.map((r) => ({ id: r.id, ...(r.data as object) }));
  res.json(exams);
});

examsRouter.post("/exams", async (req, res) => {
  if (!req.isAuthenticated()) return res.status(401).json({ error: "Unauthorized" });
  const userId = req.user!.id;
  const exam = req.body;
  if (!exam?.id) return res.status(400).json({ error: "Missing exam id" });
  await db.insert(examsTable).values({ id: exam.id, userId, data: exam }).onConflictDoUpdate({
    target: examsTable.id,
    set: { data: exam, updatedAt: new Date() },
  });
  res.json({ ok: true });
});

examsRouter.delete("/exams/:id", async (req, res) => {
  if (!req.isAuthenticated()) return res.status(401).json({ error: "Unauthorized" });
  const userId = req.user!.id;
  await db.delete(examsTable).where(
    eq(examsTable.id, req.params.id)
  );
  res.json({ ok: true });
});

export default examsRouter;
