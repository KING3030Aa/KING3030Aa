const QUOTES = [
  { text: "Success is not final, failure is not fatal — it is the courage to continue that counts.", author: "Winston Churchill" },
  { text: "The secret of getting ahead is getting started.", author: "Mark Twain" },
  { text: "Don't watch the clock; do what it does — keep going.", author: "Sam Levenson" },
  { text: "Believe you can and you're halfway there.", author: "Theodore Roosevelt" },
  { text: "It always seems impossible until it is done.", author: "Nelson Mandela" },
  { text: "Hard work beats talent when talent doesn't work hard.", author: "Tim Notke" },
  { text: "The more that you read, the more things you will know.", author: "Dr. Seuss" },
  { text: "An investment in knowledge pays the best interest.", author: "Benjamin Franklin" },
  { text: "The expert in anything was once a beginner.", author: "Helen Hayes" },
  { text: "You don't have to be great to start, but you have to start to be great.", author: "Zig Ziglar" },
  { text: "JEE is not about intelligence — it's about consistency and right strategy.", author: "Toppers' Wisdom" },
  { text: "Every problem in physics has a pattern. Find it and you've already solved it.", author: "Study Mantra" },
  { text: "Chemistry is 40% logic, 60% practice. Practice daily.", author: "Study Mantra" },
  { text: "Mathematics is not about numbers — it's about understanding patterns.", author: "Study Mantra" },
  { text: "One hour of focused study is worth more than four hours of distracted effort.", author: "Learning Science" },
  { text: "Your rank is determined by what you do in the next 30 days, not the next 30 minutes.", author: "JEE Wisdom" },
  { text: "Stop comparing yourself to others — compare yourself to who you were yesterday.", author: "Jordan Peterson" },
  { text: "The pain of studying is temporary. The regret of not trying lasts forever.", author: "Unknown" },
  { text: "Small daily improvements over time lead to stunning results.", author: "Robin Sharma" },
  { text: "You are capable of more than you know.", author: "E.O. Wilson" },
  { text: "Comfort is the enemy of achievement.", author: "Farrah Gray" },
  { text: "Focus on the process, and the results will take care of themselves.", author: "Nick Saban" },
  { text: "Do something today that your future self will thank you for.", author: "Sean Patrick Flanery" },
  { text: "The difference between ordinary and extraordinary is that little 'extra'.", author: "Jimmy Johnson" },
  { text: "Consistency is what transforms average into excellence.", author: "Unknown" },
  { text: "Physics taught me that every force has a reaction — effort brings results.", author: "Study Mantra" },
  { text: "A problem well stated is a problem half solved.", author: "Charles Kettering" },
  { text: "The harder you work for something, the greater you'll feel when you achieve it.", author: "Unknown" },
  { text: "Don't count the days — make the days count.", author: "Muhammad Ali" },
  { text: "Success usually comes to those who are too busy to be looking for it.", author: "Henry David Thoreau" },
];

export function getDailyQuote() {
  const dayOfYear = Math.floor(
    (Date.now() - new Date(new Date().getFullYear(), 0, 0).getTime()) / 86400000
  );
  return QUOTES[dayOfYear % QUOTES.length];
}
