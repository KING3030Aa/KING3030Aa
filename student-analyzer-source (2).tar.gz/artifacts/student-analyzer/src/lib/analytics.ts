import type { Exam, SubjectStats, AnalysisInsight, RankPrediction } from "./types";

export function getTotalAndPercentage(exam: Exam) {
  const total = exam.subjects.reduce((s, sub) => s + sub.marksObtained, 0);
  const maxTotal = exam.subjects.reduce((s, sub) => s + sub.maxMarks, 0);
  const percentage = maxTotal > 0 ? (total / maxTotal) * 100 : 0;
  return { total, maxTotal, percentage };
}

export function getSubjectPercentage(marksObtained: number, maxMarks: number) {
  return maxMarks > 0 ? (marksObtained / maxMarks) * 100 : 0;
}

export function computeSubjectStats(exams: Exam[]): SubjectStats[] {
  const map: Record<string, number[]> = {};

  for (const exam of exams) {
    for (const sub of exam.subjects) {
      const pct = getSubjectPercentage(sub.marksObtained, sub.maxMarks);
      if (!map[sub.name]) map[sub.name] = [];
      map[sub.name].push(pct);
    }
  }

  return Object.entries(map).map(([name, percentages]) => {
    const average = percentages.reduce((a, b) => a + b, 0) / percentages.length;
    let trend: SubjectStats["trend"] = "stable";
    let trendValue = 0;

    if (percentages.length >= 2) {
      const last = percentages[percentages.length - 1];
      const secondLast = percentages[percentages.length - 2];
      trendValue = last - secondLast;
      if (trendValue > 2) trend = "improving";
      else if (trendValue < -2) trend = "declining";
    }

    return { name, percentages, average, trend, trendValue };
  });
}

export function generateInsights(exams: Exam[], stats: SubjectStats[]): AnalysisInsight[] {
  const insights: AnalysisInsight[] = [];

  if (exams.length < 1) return insights;

  const sortedStats = [...stats].sort((a, b) => b.average - a.average);
  const strongSubjects = sortedStats.filter((s) => s.average >= 70);
  const weakSubjects = sortedStats.filter((s) => s.average < 50);
  const midSubjects = sortedStats.filter((s) => s.average >= 50 && s.average < 70);

  for (const s of strongSubjects.slice(0, 2)) {
    insights.push({
      type: "strong",
      subject: s.name,
      message: `You are performing strongly in ${s.name} with an average of ${s.average.toFixed(1)}%. Keep it up!`,
    });
  }

  for (const s of weakSubjects) {
    insights.push({
      type: "weak",
      subject: s.name,
      message: `${s.name} needs attention — your average is ${s.average.toFixed(1)}%. Focus on fundamentals and practice problems.`,
    });
  }

  for (const s of midSubjects) {
    insights.push({
      type: "info",
      subject: s.name,
      message: `${s.name} is at a moderate level (${s.average.toFixed(1)}%). Consistent revision can push it to the next tier.`,
    });
  }

  if (exams.length >= 3) {
    for (const s of stats) {
      if (s.percentages.length >= 3) {
        const last3 = s.percentages.slice(-3);
        const dropFrom = last3[0];
        const dropTo = last3[2];
        const drop = dropFrom - dropTo;
        if (drop > 10) {
          insights.push({
            type: "warning",
            subject: s.name,
            message: `Your ${s.name} score is dropping by ${drop.toFixed(1)}% over the last 3 tests. Consider revisiting recent topics.`,
          });
        }
      }
    }
  }

  for (const s of stats) {
    if (s.percentages.length >= 2 && s.trend === "improving") {
      insights.push({
        type: "info",
        subject: s.name,
        message: `${s.name} is trending upward (+${s.trendValue.toFixed(1)}% in the last test). Great progress!`,
      });
    }
  }

  const allPercentages = exams.map((e) => getTotalAndPercentage(e).percentage);
  if (allPercentages.length >= 3) {
    const variance =
      allPercentages.reduce((sum, p) => {
        const mean = allPercentages.reduce((a, b) => a + b, 0) / allPercentages.length;
        return sum + Math.pow(p - mean, 2);
      }, 0) / allPercentages.length;
    const std = Math.sqrt(variance);
    if (std < 5) {
      insights.push({
        type: "info",
        message: "You show excellent consistency across exams. Your scores are very stable.",
      });
    } else if (std > 15) {
      insights.push({
        type: "warning",
        message: `Your scores vary significantly (±${std.toFixed(1)}%). Work on consistency — it's key for competitive exams.`,
      });
    }
  }

  const latestExam = exams[exams.length - 1];
  const latestPct = getTotalAndPercentage(latestExam).percentage;

  if (latestPct >= 85) {
    insights.push({
      type: "suggestion",
      message: "Excellent scores! Consider attempting previous year JEE papers for exposure to actual exam patterns.",
    });
  } else if (latestPct >= 65) {
    insights.push({
      type: "suggestion",
      message: "You're on the right track! Increase your mock test frequency and focus on time management.",
    });
  } else if (latestPct >= 45) {
    insights.push({
      type: "suggestion",
      message: "Focus more on revision and timed practice. Identify and prioritize high-weightage chapters.",
    });
  } else {
    insights.push({
      type: "suggestion",
      message: "Start with NCERT basics for each subject. Set daily study goals and track your chapter-by-chapter progress.",
    });
  }

  if (weakSubjects.length > 0) {
    const names = weakSubjects.map((s) => s.name).join(" and ");
    insights.push({
      type: "suggestion",
      message: `Dedicate at least 2 hours daily to ${names}. Use spaced repetition for formula-heavy topics.`,
    });
  }

  return insights;
}

export function generateStudyDistribution(stats: SubjectStats[]): { subject: string; hours: number }[] {
  if (stats.length === 0) return [];
  const totalWeight = stats.reduce((sum, s) => sum + (100 - s.average), 0);
  const totalHours = 8;
  return stats.map((s) => ({
    subject: s.name,
    hours:
      totalWeight > 0
        ? Math.max(1, Math.round(((100 - s.average) / totalWeight) * totalHours * 10) / 10)
        : totalHours / stats.length,
  }));
}

const JEE_MAINS_CUTOFFS: Record<number, number> = {
  2024: 90,
  2023: 88,
  2022: 87,
  2021: 87,
};

const JEE_ADVANCED_CUTOFFS: Record<number, number> = {
  2024: 87,
  2023: 84,
  2022: 82,
  2021: 75,
};

export function predictRank(overallPercentage: number, examType: string): RankPrediction | null {
  if (examType === "Other") return null;

  const cutoffs = examType === "JEE Mains" ? JEE_MAINS_CUTOFFS : JEE_ADVANCED_CUTOFFS;
  const latestCutoff = cutoffs[2024];

  let percentile = 0;
  let estimatedRank = "";

  if (examType === "JEE Mains") {
    percentile = Math.min(99.99, Math.max(0, (overallPercentage / 100) * 99 + Math.random() * 0.5));
    if (percentile >= 99.5) estimatedRank = "< 500";
    else if (percentile >= 99) estimatedRank = "500 – 5,000";
    else if (percentile >= 98) estimatedRank = "5,000 – 20,000";
    else if (percentile >= 95) estimatedRank = "20,000 – 50,000";
    else if (percentile >= 90) estimatedRank = "50,000 – 1,00,000";
    else estimatedRank = "> 1,00,000";
  } else {
    percentile = Math.min(99.9, Math.max(0, (overallPercentage / 100) * 98 + Math.random() * 0.3));
    if (percentile >= 99) estimatedRank = "< 500";
    else if (percentile >= 97) estimatedRank = "500 – 2,500";
    else if (percentile >= 95) estimatedRank = "2,500 – 5,000";
    else if (percentile >= 90) estimatedRank = "5,000 – 10,000";
    else estimatedRank = "> 10,000";
  }

  let status: "above" | "below" | "near" = "below";
  if (overallPercentage >= latestCutoff + 5) status = "above";
  else if (overallPercentage >= latestCutoff - 5) status = "near";

  return {
    examType,
    estimatedRank,
    percentile: Math.round(percentile * 100) / 100,
    cutoff2024: latestCutoff,
    status,
  };
}
