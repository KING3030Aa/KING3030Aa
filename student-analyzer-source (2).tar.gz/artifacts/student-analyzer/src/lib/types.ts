export interface SubjectEntry {
  id: string;
  name: string;
  marksObtained: number;
  maxMarks: number;
}

export interface Exam {
  id: string;
  name: string;
  examType: "JEE Mains" | "JEE Advanced" | "Other";
  date: string;
  subjects: SubjectEntry[];
}

export interface SubjectStats {
  name: string;
  percentages: number[];
  average: number;
  trend: "improving" | "declining" | "stable";
  trendValue: number;
}

export interface AnalysisInsight {
  type: "strong" | "weak" | "warning" | "suggestion" | "info";
  subject?: string;
  message: string;
}

export interface RankPrediction {
  examType: string;
  estimatedRank: string;
  percentile: number;
  cutoff2024: number;
  status: "above" | "below" | "near";
}
