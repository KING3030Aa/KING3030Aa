import { createContext, useContext, useState, useCallback, useEffect, useRef } from "react";
import type { Exam } from "./types";

const STORAGE_KEY = "jee-analyzer-exams";

function loadExams(): Exam[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

function persistExams(exams: Exam[]): void {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(exams));
}

interface ExamStoreValue {
  exams: Exam[];
  loading: boolean;
  addExam: (exam: Exam) => Promise<void>;
  updateExam: (id: string, updated: Exam) => Promise<void>;
  deleteExam: (id: string) => Promise<void>;
}

export const ExamStoreContext = createContext<ExamStoreValue | null>(null);

export function useExamStoreProvider(): ExamStoreValue {
  const [exams, setExams] = useState<Exam[]>([]);
  const [loading, setLoading] = useState(true);
  const examsRef = useRef<Exam[]>([]);
  examsRef.current = exams;

  useEffect(() => {
    setExams(loadExams());
    setLoading(false);
  }, []);

  const addExam = useCallback(async (exam: Exam) => {
    const next = [...examsRef.current, exam];
    setExams(next);
    persistExams(next);
  }, []);

  const updateExam = useCallback(async (id: string, updated: Exam) => {
    const next = examsRef.current.map((e) => (e.id === id ? updated : e));
    setExams(next);
    persistExams(next);
  }, []);

  const deleteExam = useCallback(async (id: string) => {
    const next = examsRef.current.filter((e) => e.id !== id);
    setExams(next);
    persistExams(next);
  }, []);

  return { exams, loading, addExam, updateExam, deleteExam };
}

export function useExamStore(): ExamStoreValue {
  const ctx = useContext(ExamStoreContext);
  if (!ctx) throw new Error("useExamStore must be used inside ExamStoreProvider");
  return ctx;
}
