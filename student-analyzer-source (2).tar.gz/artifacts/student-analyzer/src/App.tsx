import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "@/lib/theme";
import { Layout } from "@/components/Layout";
import { ExamStoreContext, useExamStoreProvider } from "@/lib/store";
import Dashboard from "@/pages/Dashboard";
import ExamEntry from "@/pages/ExamEntry";
import Performance from "@/pages/Performance";
import Analysis from "@/pages/Analysis";
import Suggestions from "@/pages/Suggestions";
import NotFound from "@/pages/not-found";

const queryClient = new QueryClient();

function Router() {
  return (
    <Layout>
      <Switch>
        <Route path="/" component={Dashboard} />
        <Route path="/entry" component={ExamEntry} />
        <Route path="/performance" component={Performance} />
        <Route path="/analysis" component={Analysis} />
        <Route path="/suggestions" component={Suggestions} />
        <Route component={NotFound} />
      </Switch>
    </Layout>
  );
}

function ExamStoreProvider({ children }: { children: React.ReactNode }) {
  const store = useExamStoreProvider();
  return (
    <ExamStoreContext.Provider value={store}>
      {children}
    </ExamStoreContext.Provider>
  );
}

function App() {
  return (
    <ThemeProvider>
      <QueryClientProvider client={queryClient}>
        <TooltipProvider>
          <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
            <ExamStoreProvider>
              <Router />
            </ExamStoreProvider>
          </WouterRouter>
          <Toaster />
        </TooltipProvider>
      </QueryClientProvider>
    </ThemeProvider>
  );
}

export default App;
