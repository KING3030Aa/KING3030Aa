import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useTheme } from "@/lib/theme";
import {
  LayoutDashboard,
  PlusCircle,
  BarChart3,
  Brain,
  Lightbulb,
  Menu,
  X,
  Moon,
  Sun,
  GraduationCap,
  ChevronLeft,
  ChevronRight,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

const navItems = [
  { href: "/", label: "Dashboard", icon: LayoutDashboard },
  { href: "/entry", label: "Add Exam", icon: PlusCircle },
  { href: "/performance", label: "Performance", icon: BarChart3 },
  { href: "/analysis", label: "AI Analysis", icon: Brain },
  { href: "/suggestions", label: "Suggestions", icon: Lightbulb },
];

export function Layout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  const { theme, toggleTheme } = useTheme();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [collapsed, setCollapsed] = useState(false);

  const sidebarW = collapsed ? "w-16" : "w-60";
  const mainML = collapsed ? "md:ml-16" : "md:ml-60";

  return (
    <div className="flex min-h-screen bg-background">

      {/* ── Desktop Sidebar ── */}
      <aside
        className={cn(
          "hidden md:flex flex-col bg-sidebar text-sidebar-foreground border-r border-sidebar-border shrink-0 fixed h-full z-30 transition-[width] duration-200 overflow-hidden",
          sidebarW
        )}
      >
        {/* Header */}
        <div className={cn(
          "flex items-center border-b border-sidebar-border shrink-0 transition-all duration-200",
          collapsed ? "justify-center px-0 py-5" : "gap-3 px-5 py-5"
        )}>
          <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-indigo-500 to-violet-600 flex items-center justify-center shrink-0 shadow-md shadow-indigo-500/30">
            <GraduationCap className="text-white w-5 h-5" />
          </div>
          {!collapsed && (
            <div className="leading-tight overflow-hidden whitespace-nowrap">
              <p className="text-sm font-bold text-sidebar-foreground">JEE Analyzer</p>
              <p className="text-xs text-muted-foreground">Performance Tracker</p>
            </div>
          )}
        </div>

        {/* Nav */}
        <nav className="flex-1 px-2 py-4 space-y-1">
          {navItems.map(({ href, label, icon: Icon }) => {
            const active = location === href;
            return (
              <Link
                key={href}
                href={href}
                title={collapsed ? label : undefined}
                data-testid={`nav-${label.toLowerCase().replace(" ", "-")}`}
                className={cn(
                  "flex items-center gap-3 rounded-lg text-sm font-medium transition-colors",
                  collapsed ? "justify-center px-0 py-2.5 w-full" : "px-3 py-2.5",
                  active
                    ? "bg-sidebar-primary text-sidebar-primary-foreground"
                    : "text-sidebar-foreground/70 hover:bg-sidebar-accent hover:text-sidebar-foreground"
                )}
              >
                <Icon className="w-4 h-4 shrink-0" />
                {!collapsed && <span className="whitespace-nowrap">{label}</span>}
              </Link>
            );
          })}
        </nav>

        {/* Bottom: theme + collapse */}
        <div className="px-2 py-3 border-t border-sidebar-border space-y-1">
          <Button
            variant="ghost"
            size="sm"
            onClick={toggleTheme}
            title={collapsed ? (theme === "dark" ? "Light Mode" : "Dark Mode") : undefined}
            data-testid="theme-toggle"
            className={cn(
              "w-full text-sidebar-foreground/70 hover:text-sidebar-foreground hover:bg-sidebar-accent",
              collapsed ? "justify-center px-0" : "justify-start gap-2"
            )}
          >
            {theme === "dark" ? <Sun className="w-4 h-4 shrink-0" /> : <Moon className="w-4 h-4 shrink-0" />}
            {!collapsed && (theme === "dark" ? "Light Mode" : "Dark Mode")}
          </Button>

          {/* Collapse toggle */}
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setCollapsed((c) => !c)}
            title={collapsed ? "Expand sidebar" : "Collapse sidebar"}
            data-testid="sidebar-collapse-toggle"
            className={cn(
              "w-full text-sidebar-foreground/70 hover:text-sidebar-foreground hover:bg-sidebar-accent",
              collapsed ? "justify-center px-0" : "justify-start gap-2"
            )}
          >
            {collapsed
              ? <ChevronRight className="w-4 h-4 shrink-0" />
              : <><ChevronLeft className="w-4 h-4 shrink-0" /><span>Collapse</span></>
            }
          </Button>
        </div>
      </aside>

      {/* ── Mobile header ── */}
      <div className="md:hidden fixed top-0 left-0 right-0 z-40 bg-sidebar text-sidebar-foreground border-b border-sidebar-border h-14 flex items-center justify-between px-4">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-indigo-500 to-violet-600 flex items-center justify-center shadow-sm">
            <GraduationCap className="text-white w-4 h-4" />
          </div>
          <span className="font-bold text-sm">JEE Analyzer</span>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="ghost" size="icon" onClick={toggleTheme} className="text-sidebar-foreground/70 h-8 w-8">
            {theme === "dark" ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
          </Button>
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setMobileOpen(!mobileOpen)}
            className="text-sidebar-foreground/70 h-8 w-8"
            data-testid="mobile-menu-toggle"
          >
            {mobileOpen ? <X className="w-4 h-4" /> : <Menu className="w-4 h-4" />}
          </Button>
        </div>
      </div>

      {/* ── Mobile drawer ── */}
      {mobileOpen && (
        <div className="md:hidden fixed inset-0 z-50 bg-black/40" onClick={() => setMobileOpen(false)}>
          <div
            className="absolute left-0 top-0 h-full w-64 bg-sidebar text-sidebar-foreground border-r border-sidebar-border"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center gap-3 px-5 py-5 border-b border-sidebar-border">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-indigo-500 to-violet-600 flex items-center justify-center">
                <GraduationCap className="text-white w-5 h-5" />
              </div>
              <div className="leading-tight">
                <p className="text-sm font-bold">JEE Analyzer</p>
                <p className="text-xs text-muted-foreground">Performance Tracker</p>
              </div>
            </div>
            <nav className="px-3 py-4 space-y-1">
              {navItems.map(({ href, label, icon: Icon }) => {
                const active = location === href;
                return (
                  <Link
                    key={href}
                    href={href}
                    onClick={() => setMobileOpen(false)}
                    className={cn(
                      "flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors",
                      active
                        ? "bg-sidebar-primary text-sidebar-primary-foreground"
                        : "text-sidebar-foreground/70 hover:bg-sidebar-accent hover:text-sidebar-foreground"
                    )}
                  >
                    <Icon className="w-4 h-4 shrink-0" />
                    {label}
                  </Link>
                );
              })}
            </nav>
          </div>
        </div>
      )}

      {/* ── Main content ── */}
      <main className={cn("flex-1 pt-14 md:pt-0 min-h-screen transition-[margin] duration-200", mainML)}>
        <div className="p-4 md:p-8 max-w-5xl mx-auto">{children}</div>
      </main>
    </div>
  );
}
