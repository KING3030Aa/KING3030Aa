import { useState } from "react";
import { useExamStore } from "@/lib/store";
import { getTotalAndPercentage, getSubjectPercentage, computeSubjectStats } from "@/lib/analytics";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import type { Exam } from "@/lib/types";
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  ReferenceLine,
} from "recharts";
import { TrendingUp, TrendingDown, Minus } from "lucide-react";
import { cn } from "@/lib/utils";

const SUBJECT_COLORS = [
  "hsl(246,80%,62%)",
  "hsl(168,76%,42%)",
  "hsl(38,92%,50%)",
  "hsl(0,72%,51%)",
  "hsl(291,63%,55%)",
];

const EXAM_TYPES = ["JEE Mains", "JEE Advanced", "Other"] as const;

const tooltipStyle = {
  background: "hsl(var(--card))",
  border: "1px solid hsl(var(--card-border))",
  borderRadius: "8px",
  fontSize: 12,
  color: "hsl(var(--card-foreground))",
};

function EmptyState({ message }: { message: string }) {
  return (
    <div className="flex items-center justify-center h-40 text-sm text-muted-foreground">
      {message}
    </div>
  );
}

function ExamSection({ exams }: { exams: Exam[] }) {
  const stats = computeSubjectStats(exams);
  const allSubjects = Array.from(new Set(exams.flatMap((e) => e.subjects.map((s) => s.name))));

  const lineData = exams.map((exam) => {
    const row: Record<string, string | number> = {
      name: exam.name.length > 16 ? exam.name.slice(0, 14) + "…" : exam.name,
      overall: Math.round(getTotalAndPercentage(exam).percentage * 10) / 10,
    };
    for (const sub of exam.subjects) {
      row[sub.name] = Math.round(getSubjectPercentage(sub.marksObtained, sub.maxMarks) * 10) / 10;
    }
    return row;
  });

  const barData = stats.map((s) => ({
    subject: s.name,
    average: Math.round(s.average * 10) / 10,
  }));

  if (exams.length === 0) {
    return <EmptyState message="No exams of this type added yet." />;
  }

  return (
    <div className="space-y-5">
      {/* Overall score trend */}
      <Card className="border border-card-border shadow-sm">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-semibold">Overall Score Trend</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-56" data-testid="chart-overall-trend">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={lineData} margin={{ top: 5, right: 20, left: -10, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis dataKey="name" tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }} />
                <YAxis domain={["auto", 100]} tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }} unit="%" />
                <Tooltip contentStyle={tooltipStyle} formatter={(v: number) => [`${v}%`]} />
                <ReferenceLine y={50} stroke="hsl(var(--destructive))" strokeDasharray="4 4" strokeOpacity={0.5} />
                <Line
                  type="monotone"
                  dataKey="overall"
                  stroke="hsl(var(--primary))"
                  strokeWidth={2.5}
                  dot={{ r: 4, fill: "hsl(var(--primary))" }}
                  activeDot={{ r: 6 }}
                  name="Overall %"
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      {/* Subject-wise trend */}
      {allSubjects.length > 0 && (
        <Card className="border border-card-border shadow-sm">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold">Subject-wise Trend</CardTitle>
          </CardHeader>
          <CardContent>
            {exams.length < 2 ? (
              <EmptyState message="Add at least 2 exams to see subject trends." />
            ) : (
              <div className="h-56" data-testid="chart-subject-trend">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={lineData} margin={{ top: 5, right: 20, left: -10, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                    <XAxis dataKey="name" tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }} />
                    <YAxis domain={["auto", 100]} tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }} unit="%" />
                    <Tooltip contentStyle={tooltipStyle} formatter={(v: number) => [`${v}%`]} />
                    <Legend wrapperStyle={{ fontSize: 12 }} />
                    {allSubjects.map((sub, i) => (
                      <Line
                        key={sub}
                        type="monotone"
                        dataKey={sub}
                        stroke={SUBJECT_COLORS[i % SUBJECT_COLORS.length]}
                        strokeWidth={2}
                        dot={{ r: 3 }}
                        activeDot={{ r: 5 }}
                        connectNulls
                      />
                    ))}
                  </LineChart>
                </ResponsiveContainer>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Subject average comparison */}
      {barData.length > 0 && (
        <Card className="border border-card-border shadow-sm">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold">Subject Average Comparison</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-52" data-testid="chart-subject-bar">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={barData} margin={{ top: 5, right: 20, left: -10, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis dataKey="subject" tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }} />
                  <YAxis domain={["auto", 100]} tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }} unit="%" />
                  <Tooltip contentStyle={tooltipStyle} formatter={(v: number) => [`${v}%`]} />
                  <ReferenceLine y={70} stroke="hsl(168,76%,42%)" strokeDasharray="4 4" strokeOpacity={0.5} label={{ value: "Strong", fontSize: 10, fill: "hsl(168,76%,42%)" }} />
                  <ReferenceLine y={50} stroke="hsl(38,92%,50%)" strokeDasharray="4 4" strokeOpacity={0.5} label={{ value: "Pass", fontSize: 10, fill: "hsl(38,92%,50%)" }} />
                  <Bar dataKey="average" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} name="Avg %" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Exam detail table */}
      <Card className="border border-card-border shadow-sm">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-semibold">Exam Detail Table</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-sm" data-testid="exam-detail-table">
              <thead>
                <tr className="border-b border-border">
                  <th className="text-left py-2 pr-4 text-muted-foreground font-medium">Exam</th>
                  <th className="text-left py-2 pr-4 text-muted-foreground font-medium">Date</th>
                  <th className="text-right py-2 pr-4 text-muted-foreground font-medium">Score</th>
                  <th className="text-right py-2 text-muted-foreground font-medium">%</th>
                </tr>
              </thead>
              <tbody>
                {exams.map((exam, idx) => {
                  const { total, maxTotal, percentage } = getTotalAndPercentage(exam);
                  const prev = idx > 0 ? getTotalAndPercentage(exams[idx - 1]).percentage : null;
                  const delta = prev !== null ? percentage - prev : null;
                  return (
                    <tr key={exam.id} className="border-b border-border last:border-0" data-testid={`table-row-${exam.id}`}>
                      <td className="py-2.5 pr-4 font-medium text-foreground">{exam.name}</td>
                      <td className="py-2.5 pr-4 text-muted-foreground">{exam.date}</td>
                      <td className="py-2.5 pr-4 text-right font-mono text-muted-foreground">{total}/{maxTotal}</td>
                      <td className="py-2.5 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          {delta !== null && (
                            <span className={cn("text-xs", delta > 0 ? "text-chart-2" : delta < 0 ? "text-destructive" : "text-muted-foreground")}>
                              {delta > 0 ? <TrendingUp className="w-3 h-3 inline" /> : delta < 0 ? <TrendingDown className="w-3 h-3 inline" /> : <Minus className="w-3 h-3 inline" />}
                            </span>
                          )}
                          <Badge
                            variant="secondary"
                            className={cn(
                              "font-mono text-xs",
                              percentage >= 70 ? "bg-chart-2/15 text-chart-2" :
                              percentage >= 50 ? "bg-chart-3/15 text-chart-3" :
                              "bg-destructive/15 text-destructive"
                            )}
                          >
                            {percentage.toFixed(1)}%
                          </Badge>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

export default function Performance() {
  const { exams } = useExamStore();
  const [activeType, setActiveType] = useState<typeof EXAM_TYPES[number]>("JEE Mains");

  if (exams.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-24 text-center">
        <p className="text-muted-foreground">Add at least one exam to see performance charts.</p>
      </div>
    );
  }

  const filteredExams = exams.filter((e) => e.examType === activeType);

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-2xl font-bold text-foreground" data-testid="page-title">Performance Charts</h1>
        <p className="text-sm text-muted-foreground mt-0.5">Charts and stats separated by exam type</p>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 p-1 bg-muted rounded-lg w-fit">
        {EXAM_TYPES.map((type) => {
          const count = exams.filter((e) => e.examType === type).length;
          const isActive = activeType === type;
          return (
            <button
              key={type}
              onClick={() => setActiveType(type)}
              className={cn(
                "px-4 py-1.5 rounded-md text-sm font-medium transition-all",
                isActive
                  ? "bg-background text-foreground shadow-sm"
                  : "text-muted-foreground hover:text-foreground"
              )}
            >
              {type}
              {count > 0 && (
                <span className={cn(
                  "ml-1.5 text-xs font-mono rounded-full px-1.5 py-0.5",
                  isActive ? "bg-primary/15 text-primary" : "bg-muted-foreground/20 text-muted-foreground"
                )}>
                  {count}
                </span>
              )}
            </button>
          );
        })}
      </div>

      <ExamSection exams={filteredExams} />
    </div>
  );
}
