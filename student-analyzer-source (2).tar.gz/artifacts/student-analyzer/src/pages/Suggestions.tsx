import { useExamStore } from "@/lib/store";
import { computeSubjectStats, generateStudyDistribution, getTotalAndPercentage } from "@/lib/analytics";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Lightbulb, Clock, Target, BookOpen, Zap } from "lucide-react";
import { cn } from "@/lib/utils";

const TOPIC_SUGGESTIONS: Record<string, string[]> = {
  Physics: [
    "Mechanics & Laws of Motion",
    "Electrostatics & Current Electricity",
    "Thermodynamics",
    "Optics & Modern Physics",
  ],
  Chemistry: [
    "Organic Reaction Mechanisms",
    "Chemical Bonding",
    "Equilibrium & Electrochemistry",
    "Coordination Compounds",
  ],
  Mathematics: [
    "Calculus (Integration & Differentiation)",
    "Coordinate Geometry",
    "Algebra & Trigonometry",
    "Probability & Statistics",
  ],
  Biology: [
    "Cell Biology & Genetics",
    "Plant Physiology",
    "Human Physiology",
    "Ecology & Evolution",
  ],
};

function getDefaultTopics(subject: string) {
  return TOPIC_SUGGESTIONS[subject] ?? [
    "Core Concepts Review",
    "Problem-Solving Practice",
    "Past Year Questions",
    "Formula Revision",
  ];
}

export default function Suggestions() {
  const { exams } = useExamStore();
  const stats = computeSubjectStats(exams);
  const distribution = generateStudyDistribution(stats);

  const overallAvg =
    exams.length > 0
      ? exams.reduce((sum, e) => sum + getTotalAndPercentage(e).percentage, 0) / exams.length
      : null;

  const weakSubjects = stats.filter((s) => s.average < 50);
  const midSubjects = stats.filter((s) => s.average >= 50 && s.average < 70);

  if (exams.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-24 text-center">
        <div className="w-16 h-16 rounded-2xl bg-accent flex items-center justify-center mb-4">
          <Lightbulb className="w-8 h-8 text-accent-foreground" />
        </div>
        <p className="text-muted-foreground">Add exams to unlock personalized study suggestions.</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-foreground" data-testid="page-title">Smart Suggestions</h1>
        <p className="text-sm text-muted-foreground mt-0.5">Personalized recommendations based on your performance</p>
      </div>

      {/* Study time distribution */}
      {distribution.length > 0 && (
        <Card className="border border-card-border shadow-sm">
          <CardHeader className="pb-2">
            <CardTitle className="text-base flex items-center gap-2">
              <Clock className="w-4 h-4 text-primary" />
              Recommended Daily Study Time
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <p className="text-xs text-muted-foreground">Based on your weak areas — total 8 hours/day</p>
            {distribution.map((d) => {
              const pct = Math.min(100, (d.hours / 8) * 100);
              const subjectStat = stats.find((s) => s.name === d.subject);
              return (
                <div key={d.subject} className="flex items-center gap-3" data-testid={`study-time-${d.subject.toLowerCase()}`}>
                  <span className="w-28 text-sm font-medium text-foreground shrink-0">{d.subject}</span>
                  <div className="flex-1 h-3 bg-muted rounded-full overflow-hidden">
                    <div
                      className={cn(
                        "h-full rounded-full transition-all",
                        subjectStat && subjectStat.average >= 70
                          ? "bg-chart-2"
                          : subjectStat && subjectStat.average >= 50
                          ? "bg-chart-3"
                          : "bg-primary"
                      )}
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                  <span className="text-sm font-bold text-foreground w-16 text-right">{d.hours}h</span>
                </div>
              );
            })}
          </CardContent>
        </Card>
      )}

      {/* Topics to improve */}
      {(weakSubjects.length > 0 || midSubjects.length > 0) && (
        <Card className="border border-card-border shadow-sm">
          <CardHeader className="pb-2">
            <CardTitle className="text-base flex items-center gap-2">
              <Target className="w-4 h-4 text-primary" />
              Topics to Focus On
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {[...weakSubjects, ...midSubjects].map((s) => (
              <div key={s.name} className="space-y-2" data-testid={`topics-${s.name.toLowerCase()}`}>
                <div className="flex items-center gap-2">
                  <span className="text-sm font-semibold text-foreground">{s.name}</span>
                  <Badge
                    variant="secondary"
                    className={cn("text-xs", s.average < 50 ? "bg-destructive/15 text-destructive" : "bg-chart-3/15 text-chart-3")}
                  >
                    {s.average.toFixed(0)}%
                  </Badge>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  {getDefaultTopics(s.name).map((topic) => (
                    <div
                      key={topic}
                      className="flex items-center gap-2 text-xs text-muted-foreground bg-muted/60 rounded-md px-2.5 py-2"
                    >
                      <BookOpen className="w-3 h-3 shrink-0 text-primary" />
                      {topic}
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {/* Mock test strategy */}
      <Card className="border border-card-border shadow-sm">
        <CardHeader className="pb-2">
          <CardTitle className="text-base flex items-center gap-2">
            <Zap className="w-4 h-4 text-primary" />
            Mock Test Strategy
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {overallAvg !== null && (
            <div className="p-3 rounded-lg bg-muted/50 border border-border" data-testid="strategy-overview">
              <p className="text-sm font-medium text-foreground">Your current average: {overallAvg.toFixed(1)}%</p>
              <p className="text-xs text-muted-foreground mt-0.5">
                {overallAvg >= 85
                  ? "Excellent! Simulate full 3-hour JEE papers once a week."
                  : overallAvg >= 65
                  ? "Good progress! Take 2–3 subject-level mocks per week."
                  : overallAvg >= 45
                  ? "Build fundamentals first. Take 1 mock per week focusing on accuracy."
                  : "Focus on concept building. Attempt chapter-wise tests before full mocks."}
              </p>
            </div>
          )}

          <div className="space-y-2">
            {[
              {
                title: "Accuracy over Speed",
                tip: "In early preparation, prioritize getting questions right over finishing quickly.",
              },
              {
                title: "Time yourself",
                tip: "Use a timer for every practice session to simulate real exam conditions.",
              },
              {
                title: "Review mistakes",
                tip: "Spend equal time reviewing wrong answers as you do on new questions.",
              },
              {
                title: "Spaced Repetition",
                tip: "Revise topics after 1 day, 3 days, 1 week, and 1 month for long-term retention.",
              },
              {
                title: "Previous Years",
                tip: "Solve last 10 years of JEE papers — patterns repeat more than you think.",
              },
            ].map((item, i) => (
              <div
                key={i}
                className="flex items-start gap-3 p-3 rounded-lg bg-accent/40 border border-accent-border"
                data-testid={`strategy-tip-${i}`}
              >
                <span className="w-5 h-5 rounded-full bg-primary text-primary-foreground text-xs flex items-center justify-center shrink-0 font-bold mt-0.5">
                  {i + 1}
                </span>
                <div>
                  <p className="text-sm font-semibold text-foreground">{item.title}</p>
                  <p className="text-xs text-muted-foreground mt-0.5">{item.tip}</p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
