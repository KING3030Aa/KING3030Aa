import { useExamStore } from "@/lib/store";
import { computeSubjectStats, generateInsights } from "@/lib/analytics";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Brain, AlertTriangle, CheckCircle, Info, Lightbulb, TrendingUp, TrendingDown, Minus } from "lucide-react";
import { cn } from "@/lib/utils";
import type { AnalysisInsight } from "@/lib/types";

const insightConfig: Record<AnalysisInsight["type"], { icon: React.ComponentType<{ className?: string }>; color: string; bg: string; label: string }> = {
  strong: { icon: CheckCircle, color: "text-chart-2", bg: "bg-chart-2/10 border-chart-2/20", label: "Strength" },
  weak: { icon: AlertTriangle, color: "text-destructive", bg: "bg-destructive/10 border-destructive/20", label: "Weakness" },
  warning: { icon: AlertTriangle, color: "text-chart-3", bg: "bg-chart-3/10 border-chart-3/20", label: "Warning" },
  suggestion: { icon: Lightbulb, color: "text-primary", bg: "bg-primary/10 border-primary/20", label: "Suggestion" },
  info: { icon: Info, color: "text-muted-foreground", bg: "bg-muted border-border", label: "Info" },
};

export default function Analysis() {
  const { exams } = useExamStore();
  const stats = computeSubjectStats(exams);
  const insights = generateInsights(exams, stats);

  if (exams.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-24 text-center">
        <div className="w-16 h-16 rounded-2xl bg-accent flex items-center justify-center mb-4">
          <Brain className="w-8 h-8 text-accent-foreground" />
        </div>
        <p className="text-muted-foreground">Add at least one exam to see AI-powered analysis.</p>
      </div>
    );
  }

  const grouped: Record<string, AnalysisInsight[]> = {
    strong: insights.filter((i) => i.type === "strong"),
    weak: insights.filter((i) => i.type === "weak"),
    warning: insights.filter((i) => i.type === "warning"),
    suggestion: insights.filter((i) => i.type === "suggestion"),
    info: insights.filter((i) => i.type === "info"),
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-foreground" data-testid="page-title">AI Analysis</h1>
        <p className="text-sm text-muted-foreground mt-0.5">Smart insights based on your performance data</p>
      </div>

      {/* Subject performance matrix */}
      {stats.length > 0 && (
        <Card className="border border-card-border shadow-sm">
          <CardHeader className="pb-2">
            <CardTitle className="text-base">Subject Performance Matrix</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {stats.map((s) => (
              <div key={s.name} className="flex items-center gap-3" data-testid={`analysis-subject-${s.name.toLowerCase()}`}>
                <div className="w-28 shrink-0">
                  <span className="text-sm font-medium text-foreground">{s.name}</span>
                </div>
                <div className="flex-1 h-3 bg-muted rounded-full overflow-hidden">
                  <div
                    className={cn(
                      "h-full rounded-full transition-all",
                      s.average >= 70 ? "bg-chart-2" : s.average >= 50 ? "bg-chart-3" : "bg-destructive"
                    )}
                    style={{ width: `${Math.min(100, s.average)}%` }}
                  />
                </div>
                <span className="w-14 text-right text-sm font-mono text-foreground">{s.average.toFixed(1)}%</span>
                <div className="w-20 shrink-0">
                  <Badge
                    className={cn(
                      "text-xs",
                      s.average >= 70 ? "bg-chart-2/15 text-chart-2" :
                      s.average >= 50 ? "bg-chart-3/15 text-chart-3" :
                      "bg-destructive/15 text-destructive"
                    )}
                    variant="secondary"
                  >
                    {s.average >= 70 ? "Strong" : s.average >= 50 ? "Moderate" : "Weak"}
                  </Badge>
                </div>
                <div className="w-6 shrink-0 flex justify-center">
                  {s.trend === "improving" ? (
                    <TrendingUp className="w-4 h-4 text-chart-2" />
                  ) : s.trend === "declining" ? (
                    <TrendingDown className="w-4 h-4 text-destructive" />
                  ) : (
                    <Minus className="w-4 h-4 text-muted-foreground" />
                  )}
                </div>
              </div>
            ))}
            <div className="flex items-center gap-4 pt-2 border-t border-border text-xs text-muted-foreground">
              <span className="flex items-center gap-1"><TrendingUp className="w-3 h-3 text-chart-2" /> Improving</span>
              <span className="flex items-center gap-1"><TrendingDown className="w-3 h-3 text-destructive" /> Declining</span>
              <span className="flex items-center gap-1"><Minus className="w-3 h-3" /> Stable</span>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Insights */}
      {insights.length > 0 ? (
        <div className="space-y-3">
          {(["strong", "weak", "warning", "suggestion", "info"] as const).map((type) => {
            const items = grouped[type];
            if (!items || items.length === 0) return null;
            const config = insightConfig[type];
            return (
              <div key={type}>
                <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide mb-2">
                  {config.label}s
                </h2>
                <div className="space-y-2">
                  {items.map((insight, i) => {
                    const Icon = config.icon;
                    return (
                      <div
                        key={i}
                        className={cn("flex items-start gap-3 p-3.5 rounded-lg border", config.bg)}
                        data-testid={`insight-${type}-${i}`}
                      >
                        <Icon className={cn("w-4 h-4 mt-0.5 shrink-0", config.color)} />
                        <div className="flex-1 min-w-0">
                          {insight.subject && (
                            <span className={cn("text-xs font-semibold mr-2", config.color)}>
                              {insight.subject}
                            </span>
                          )}
                          <span className="text-sm text-foreground">{insight.message}</span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <p className="text-muted-foreground text-sm">Keep adding more exams to unlock deeper insights.</p>
      )}
    </div>
  );
}
