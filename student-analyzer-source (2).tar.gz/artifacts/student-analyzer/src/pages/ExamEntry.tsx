import { useState } from "react";
import { useLocation } from "wouter";
import { useExamStore } from "@/lib/store";
import type { Exam, SubjectEntry } from "@/lib/types";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { PlusCircle, Trash2, Save } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const PRESET_SUBJECTS = ["Physics", "Chemistry", "Mathematics", "Biology", "English", "Other"];

function generateId() {
  return Math.random().toString(36).slice(2) + Date.now().toString(36);
}

function emptySubject(): SubjectEntry {
  return { id: generateId(), name: "Physics", marksObtained: 0, maxMarks: 100 };
}

export default function ExamEntry() {
  const { addExam } = useExamStore();
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const [examName, setExamName] = useState("");
  const [examType, setExamType] = useState<Exam["examType"]>("JEE Mains");
  const [examDate, setExamDate] = useState(new Date().toISOString().slice(0, 10));
  const [subjects, setSubjects] = useState<SubjectEntry[]>([emptySubject()]);
  const [errors, setErrors] = useState<Record<string, string>>({});

  function addSubject() {
    setSubjects((prev) => [...prev, emptySubject()]);
  }

  function removeSubject(id: string) {
    if (subjects.length === 1) return;
    setSubjects((prev) => prev.filter((s) => s.id !== id));
  }

  function updateSubject(id: string, field: keyof SubjectEntry, value: string | number) {
    setSubjects((prev) =>
      prev.map((s) => (s.id === id ? { ...s, [field]: value } : s))
    );
  }

  function validate() {
    const errs: Record<string, string> = {};
    if (!examName.trim()) errs.examName = "Exam name is required";
    subjects.forEach((sub, i) => {
      if (!sub.name.trim()) errs[`sub_${i}_name`] = "Subject name required";
      if (sub.maxMarks <= 0) errs[`sub_${i}_max`] = "Max marks must be > 0";
      if (sub.marksObtained > sub.maxMarks)
        errs[`sub_${i}_obtained`] = "Marks exceed maximum";
    });
    setErrors(errs);
    return Object.keys(errs).length === 0;
  }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!validate()) return;

    const exam: Exam = {
      id: generateId(),
      name: examName.trim(),
      examType,
      date: examDate,
      subjects,
    };

    addExam(exam);
    toast({ title: "Exam saved!", description: `"${examName}" has been recorded.` });
    setLocation("/");
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-foreground" data-testid="page-title">Add Exam</h1>
        <p className="text-sm text-muted-foreground mt-0.5">Enter your exam details and subject-wise marks</p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Exam details */}
        <Card className="border border-card-border shadow-sm">
          <CardHeader className="pb-3">
            <CardTitle className="text-base">Exam Details</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid sm:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label htmlFor="examName">Exam Name *</Label>
                <Input
                  id="examName"
                  placeholder="e.g. JEE Mains Mock Test 1"
                  value={examName}
                  onChange={(e) => setExamName(e.target.value)}
                  data-testid="input-exam-name"
                  className={errors.examName ? "border-destructive" : ""}
                />
                {errors.examName && (
                  <p className="text-xs text-destructive">{errors.examName}</p>
                )}
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="examType">Exam Type</Label>
                <Select value={examType} onValueChange={(v) => setExamType(v as Exam["examType"])}>
                  <SelectTrigger id="examType" data-testid="select-exam-type">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="JEE Mains">JEE Mains</SelectItem>
                    <SelectItem value="JEE Advanced">JEE Advanced</SelectItem>
                    <SelectItem value="Other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-1.5 max-w-xs">
              <Label htmlFor="examDate">Exam Date</Label>
              <Input
                id="examDate"
                type="date"
                value={examDate}
                onChange={(e) => setExamDate(e.target.value)}
                data-testid="input-exam-date"
              />
            </div>
          </CardContent>
        </Card>

        {/* Subjects */}
        <Card className="border border-card-border shadow-sm">
          <CardHeader className="pb-3 flex flex-row items-center justify-between">
            <CardTitle className="text-base">Subjects & Marks</CardTitle>
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={addSubject}
              className="gap-1.5"
              data-testid="btn-add-subject"
            >
              <PlusCircle className="w-4 h-4" />
              Add Subject
            </Button>
          </CardHeader>
          <CardContent className="space-y-4">
            {subjects.map((sub, i) => (
              <div
                key={sub.id}
                className="p-4 rounded-lg border border-border bg-muted/30 space-y-3"
                data-testid={`subject-entry-${i}`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-sm font-semibold text-foreground">Subject {i + 1}</span>
                  {subjects.length > 1 && (
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      onClick={() => removeSubject(sub.id)}
                      className="w-7 h-7 text-destructive hover:text-destructive hover:bg-destructive/10"
                      data-testid={`btn-remove-subject-${i}`}
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </Button>
                  )}
                </div>

                <div className="grid sm:grid-cols-3 gap-3">
                  {/* Subject name */}
                  <div className="space-y-1.5">
                    <Label>Subject Name *</Label>
                    <Select
                      value={PRESET_SUBJECTS.includes(sub.name) ? sub.name : "custom"}
                      onValueChange={(v) => {
                        if (v !== "custom") updateSubject(sub.id, "name", v);
                        else updateSubject(sub.id, "name", "");
                      }}
                    >
                      <SelectTrigger data-testid={`select-subject-${i}`} className={errors[`sub_${i}_name`] ? "border-destructive" : ""}>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {PRESET_SUBJECTS.filter(s => s !== "Other").map((s) => (
                          <SelectItem key={s} value={s}>{s}</SelectItem>
                        ))}
                        <SelectItem value="custom">Custom name...</SelectItem>
                      </SelectContent>
                    </Select>
                    {(!PRESET_SUBJECTS.includes(sub.name) || sub.name === "") && (
                      <Input
                        placeholder="Type subject name"
                        value={sub.name}
                        onChange={(e) => updateSubject(sub.id, "name", e.target.value)}
                        data-testid={`input-subject-name-${i}`}
                        autoFocus
                        className={errors[`sub_${i}_name`] ? "border-destructive" : ""}
                      />
                    )}
                    {errors[`sub_${i}_name`] && (
                      <p className="text-xs text-destructive">{errors[`sub_${i}_name`]}</p>
                    )}
                  </div>

                  {/* Marks obtained */}
                  <div className="space-y-1.5">
                    <Label>Marks Obtained *</Label>
                    <Input
                      type="number"
                      step={0.5}
                      value={sub.marksObtained}
                      onChange={(e) => updateSubject(sub.id, "marksObtained", Number(e.target.value))}
                      data-testid={`input-marks-obtained-${i}`}
                      className={errors[`sub_${i}_obtained`] ? "border-destructive" : ""}
                    />
                    {errors[`sub_${i}_obtained`] && (
                      <p className="text-xs text-destructive">{errors[`sub_${i}_obtained`]}</p>
                    )}
                  </div>

                  {/* Max marks */}
                  <div className="space-y-1.5">
                    <Label>Maximum Marks *</Label>
                    <Input
                      type="number"
                      min={1}
                      value={sub.maxMarks}
                      onChange={(e) => updateSubject(sub.id, "maxMarks", Number(e.target.value))}
                      data-testid={`input-marks-max-${i}`}
                      className={errors[`sub_${i}_max`] ? "border-destructive" : ""}
                    />
                    {errors[`sub_${i}_max`] && (
                      <p className="text-xs text-destructive">{errors[`sub_${i}_max`]}</p>
                    )}
                  </div>
                </div>

                {/* Live percentage bar */}
                {sub.maxMarks > 0 && (
                  <div className="flex items-center gap-2 pt-1">
                    <div className="flex-1 h-2 bg-muted rounded-full overflow-hidden">
                      <div
                        className={`h-full rounded-full transition-all duration-200 ${sub.marksObtained < 0 ? "bg-destructive" : "bg-primary"}`}
                        style={{ width: `${Math.min(100, Math.max(0, (sub.marksObtained / sub.maxMarks) * 100))}%` }}
                      />
                    </div>
                    <span className={`text-xs font-mono w-14 text-right ${sub.marksObtained < 0 ? "text-destructive" : "text-muted-foreground"}`}>
                      {((sub.marksObtained / sub.maxMarks) * 100).toFixed(1)}%
                    </span>
                  </div>
                )}
              </div>
            ))}
          </CardContent>
        </Card>

        <div className="flex gap-3">
          <Button type="submit" className="gap-2" data-testid="btn-save-exam">
            <Save className="w-4 h-4" />
            Save Exam
          </Button>
          <Button type="button" variant="outline" onClick={() => setLocation("/")} data-testid="btn-cancel">
            Cancel
          </Button>
        </div>
      </form>
    </div>
  );
}
