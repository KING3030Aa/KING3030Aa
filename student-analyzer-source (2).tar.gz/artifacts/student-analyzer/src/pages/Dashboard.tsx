import { useState } from "react";
import { useLocation } from "wouter";
import { useExamStore } from "@/lib/store";
import { getTotalAndPercentage, computeSubjectStats } from "@/lib/analytics";
import { getDailyQuote } from "@/lib/quotes";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  TrendingUp,
  TrendingDown,
  Minus,
  PlusCircle,
  BookOpen,
  Trophy,
  Target,
  Calendar,
  Trash2,
  Quote,
  Loader2,
} from "lucide-react";
import { cn } from "@/lib/utils";

const quote = getDailyQuote();

function StatCard({
  label,
  value,
  sub,
  icon: Icon,
  color,
  iconColor,
}: {
  label: string;
  value: string;
  sub?: string;
  icon: React.ComponentType<{ className?: string }>;
  color: string;
  iconColor: string;
}) {
  return (
    <Card className="border border-border shadow-sm overflow-hidden">
      <CardContent className="p-5">
        <div className="flex items-start justify-between">
          <div className="min-w-0">
            <p className="text-xs text-muted-foreground font-semibold uppercase tracking-wider">{label}</p>
            <p className="text-2xl font-bold mt-1 text-foreground">{value}</p>
            {sub && <p className="text-xs text-muted-foreground mt-0.5 truncate">{sub}</p>}
          </div>
          <div className={cn("w-11 h-11 rounded-xl flex items-center justify-center shrink-0", color)}>
            <Icon className={cn("w-5 h-5", iconColor)} />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

export default function Dashboard() {
  const { exams, deleteExam, loading } = useExamStore();
  const [, setLocation] = useLocation();
  const [confirmId, setConfirmId] = useState<string | null>(null);
  const stats = computeSubjectStats(exams);

  const totalExams = exams.length;
  const latestExam = exams[exams.length - 1];
  const latestPct = latestExam ? getTotalAndPercentage(latestExam).percentage : null;
  const overallAvg =
    exams.length > 0
      ? exams.reduce((sum, e) => sum + getTotalAndPercentage(e).percentage, 0) / exams.length
      : null;

  const strongCount = stats.filter((s) => s.average >= 70).length;
  const weakCount = stats.filter((s) => s.average < 50).length;

  return (
    <div className="space-y-6">

      {/* Header */}
      <div className="flex items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-foreground">
            Welcome back 👋
          </h1>
          <p className="text-sm text-muted-foreground mt-0.5">Track your JEE preparation progress</p>
        </div>
        <Button className="gap-2 shrink-0" onClick={() => setLocation("/entry")}>
          <PlusCircle className="w-4 h-4" />
          Add Exam
        </Button>
      </div>

      {/* Daily motivational quote */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-indigo-600 via-violet-600 to-purple-700 p-6 shadow-lg shadow-indigo-500/20">
        <div className="absolute top-0 right-0 w-48 h-48 bg-white/5 rounded-full -translate-y-1/2 translate-x-1/2" />
        <div className="absolute bottom-0 left-0 w-32 h-32 bg-white/5 rounded-full translate-y-1/2 -translate-x-1/2" />
        <div className="relative">
          <div className="flex items-center gap-2 mb-3">
            <Quote className="w-4 h-4 text-indigo-200" />
            <span className="text-xs font-semibold text-indigo-200 uppercase tracking-wider">Daily Motivation</span>
          </div>
          <p className="text-white font-semibold text-lg leading-snug">"{quote.text}"</p>
          <p className="text-indigo-200 text-sm mt-2">— {quote.author}</p>
        </div>
      </div>

      {/* Loading state */}
      {loading ? (
        <div className="flex items-center justify-center py-16 gap-2 text-muted-foreground">
          <Loader2 className="w-5 h-5 animate-spin" />
          <span className="text-sm">Loading your exams…</span>
        </div>
      ) : exams.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-16 text-center">
          <div className="w-16 h-16 rounded-2xl bg-accent flex items-center justify-center mb-4">
            <BookOpen className="w-8 h-8 text-accent-foreground" />
          </div>
          <h2 className="text-xl font-semibold text-foreground">No exams yet</h2>
          <p className="text-muted-foreground mt-1 max-w-sm text-sm">
            Start by adding your first exam to see performance analytics and insights.
          </p>
          <Button className="mt-6 gap-2" onClick={() => setLocation("/entry")}>
            <PlusCircle className="w-4 h-4" />
            Add Your First Exam
          </Button>
        </div>
      ) : (
        <>
          {/* Stats */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <StatCard
              label="Total Exams"
              value={String(totalExams)}
              icon={Calendar}
              color="bg-indigo-500/10"
              iconColor="text-indigo-500"
            />
            <StatCard
              label="Latest Score"
              value={latestPct !== null ? `${latestPct.toFixed(1)}%` : "—"}
              sub={latestExam?.name}
              icon={Target}
              color="bg-emerald-500/10"
              iconColor="text-emerald-500"
            />
            <StatCard
              label="Overall Avg"
              value={overallAvg !== null ? `${overallAvg.toFixed(1)}%` : "—"}
              sub="Across all exams"
              icon={TrendingUp}
              color="bg-amber-500/10"
              iconColor="text-amber-500"
            />
            <StatCard
              label="Strong Subjects"
              value={`${strongCount}/${stats.length}`}
              sub={weakCount > 0 ? `${weakCount} need attention` : "All looking good!"}
              icon={Trophy}
              color="bg-violet-500/10"
              iconColor="text-violet-500"
            />
          </div>

          {/* Subject performance */}
          {stats.length > 0 && (
            <div>
              <h2 className="text-base font-semibold text-foreground mb-3">Subject Performance</h2>
              <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {stats.map((s) => (
                  <Card key={s.name} className="border border-border shadow-xs">
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm font-semibold text-foreground">{s.name}</span>
                        <div className="flex items-center gap-1.5">
                          {s.trend === "improving" ? (
                            <TrendingUp className="w-3.5 h-3.5 text-emerald-500" />
                          ) : s.trend === "declining" ? (
                            <TrendingDown className="w-3.5 h-3.5 text-destructive" />
                          ) : (
                            <Minus className="w-3.5 h-3.5 text-muted-foreground" />
                          )}
                          <Badge
                            variant="secondary"
                            className={cn(
                              "text-xs px-1.5 font-semibold",
                              s.average >= 70
                                ? "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400"
                                : s.average >= 50
                                ? "bg-amber-500/10 text-amber-600 dark:text-amber-400"
                                : "bg-destructive/10 text-destructive"
                            )}
                          >
                            {s.average >= 70 ? "Strong" : s.average >= 50 ? "Moderate" : "Weak"}
                          </Badge>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="flex-1 h-2 bg-muted rounded-full overflow-hidden">
                          <div
                            className={cn(
                              "h-full rounded-full transition-all",
                              s.average >= 70
                                ? "bg-emerald-500"
                                : s.average >= 50
                                ? "bg-amber-500"
                                : "bg-destructive"
                            )}
                            style={{ width: `${Math.min(100, Math.max(0, s.average))}%` }}
                          />
                        </div>
                        <span className="text-sm font-mono text-muted-foreground w-12 text-right">
                          {s.average.toFixed(1)}%
                        </span>
                      </div>
                      <p className="text-xs text-muted-foreground mt-1">
                        {s.percentages.length} exam{s.percentages.length > 1 ? "s" : ""}
                      </p>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          )}

          {/* All exams list */}
          <div>
            <h2 className="text-base font-semibold text-foreground mb-3">All Exams</h2>
            <div className="space-y-2">
              {[...exams].reverse().map((exam) => {
                const { total, maxTotal, percentage } = getTotalAndPercentage(exam);
                const isConfirming = confirmId === exam.id;
                return (
                  <Card key={exam.id} className="border border-border shadow-xs">
                    <CardContent className="p-4 flex items-center gap-4">
                      {/* Percentage ring visual */}
                      <div className={cn(
                        "w-12 h-12 rounded-xl flex items-center justify-center shrink-0 font-bold text-sm",
                        percentage >= 70
                          ? "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400"
                          : percentage >= 50
                          ? "bg-amber-500/10 text-amber-600 dark:text-amber-400"
                          : "bg-destructive/10 text-destructive"
                      )}>
                        {percentage.toFixed(0)}%
                      </div>

                      <div className="min-w-0 flex-1">
                        <p className="text-sm font-semibold text-foreground truncate">{exam.name}</p>
                        <p className="text-xs text-muted-foreground mt-0.5">
                          {exam.examType} · {exam.date} · {total}/{maxTotal} marks
                        </p>
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        <Badge variant="secondary" className={cn(
                          "text-xs font-semibold hidden sm:flex",
                          exam.examType === "JEE Mains" ? "bg-indigo-500/10 text-indigo-600 dark:text-indigo-400"
                          : exam.examType === "JEE Advanced" ? "bg-violet-500/10 text-violet-600 dark:text-violet-400"
                          : "bg-slate-500/10 text-slate-600 dark:text-slate-400"
                        )}>
                          {exam.examType}
                        </Badge>

                        {isConfirming ? (
                          <div className="flex items-center gap-1">
                            <span className="text-xs text-muted-foreground">Delete?</span>
                            <Button size="sm" variant="destructive" className="h-7 px-2 text-xs"
                              onClick={() => { deleteExam(exam.id); setConfirmId(null); }}>
                              Yes
                            </Button>
                            <Button size="sm" variant="outline" className="h-7 px-2 text-xs"
                              onClick={() => setConfirmId(null)}>
                              No
                            </Button>
                          </div>
                        ) : (
                          <Button size="icon" variant="ghost"
                            className="h-8 w-8 text-muted-foreground hover:text-destructive hover:bg-destructive/10"
                            onClick={() => setConfirmId(exam.id)} title="Delete exam">
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </div>
        </>
      )}
    </div>
  );
}
