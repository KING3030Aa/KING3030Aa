import { useState } from "react";
import { useExamStore } from "@/lib/store";
import { computeSubjectStats, getTotalAndPercentage, predictRank } from "@/lib/analytics";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Trophy, Target, TrendingUp, Info } from "lucide-react";
import { cn } from "@/lib/utils";
import type { RankPrediction } from "@/lib/types";

export default function RankPredictor() {
  const { exams } = useExamStore();
  const stats = computeSubjectStats(exams);

  const latestExam = exams.length > 0 ? exams[exams.length - 1] : null;
  const autoPercentage = latestExam
    ? getTotalAndPercentage(latestExam).percentage
    : 0;

  const [customPercentage, setCustomPercentage] = useState<string>(
    autoPercentage > 0 ? autoPercentage.toFixed(1) : ""
  );
  const [examType, setExamType] = useState<"JEE Mains" | "JEE Advanced">("JEE Mains");
  const [prediction, setPrediction] = useState<RankPrediction | null>(null);

  function handlePredict() {
    const pct = parseFloat(customPercentage);
    if (isNaN(pct) || pct < 0 || pct > 100) return;
    const result = predictRank(pct, examType);
    setPrediction(result);
  }

  const cutoffHistory = examType === "JEE Mains"
    ? [
        { year: 2024, cutoff: 90 },
        { year: 2023, cutoff: 88 },
        { year: 2022, cutoff: 87 },
        { year: 2021, cutoff: 87 },
      ]
    : [
        { year: 2024, cutoff: 87 },
        { year: 2023, cutoff: 84 },
        { year: 2022, cutoff: 82 },
        { year: 2021, cutoff: 75 },
      ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-foreground" data-testid="page-title">Rank Predictor</h1>
        <p className="text-sm text-muted-foreground mt-0.5">Estimate your rank and percentile based on performance</p>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        {/* Input */}
        <Card className="border border-card-border shadow-sm">
          <CardHeader className="pb-2">
            <CardTitle className="text-base">Enter Details</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-1.5">
              <Label>Exam Type</Label>
              <Select value={examType} onValueChange={(v) => setExamType(v as typeof examType)}>
                <SelectTrigger data-testid="select-rank-exam-type">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="JEE Mains">JEE Mains</SelectItem>
                  <SelectItem value="JEE Advanced">JEE Advanced</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-1.5">
              <Label>Overall Percentage (%)</Label>
              <Input
                type="number"
                min={0}
                max={100}
                step={0.1}
                value={customPercentage}
                onChange={(e) => setCustomPercentage(e.target.value)}
                placeholder="e.g. 78.5"
                data-testid="input-percentage"
              />
              {exams.length > 0 && (
                <p className="text-xs text-muted-foreground">
                  Latest exam: {autoPercentage.toFixed(1)}%{" "}
                  <button
                    type="button"
                    className="text-primary underline underline-offset-2 text-xs"
                    onClick={() => setCustomPercentage(autoPercentage.toFixed(1))}
                    data-testid="btn-use-latest"
                  >
                    Use this
                  </button>
                </p>
              )}
            </div>

            <Button onClick={handlePredict} className="w-full gap-2" data-testid="btn-predict">
              <Trophy className="w-4 h-4" />
              Predict Rank
            </Button>
          </CardContent>
        </Card>

        {/* Prediction result */}
        <Card className="border border-card-border shadow-sm">
          <CardHeader className="pb-2">
            <CardTitle className="text-base">Prediction Result</CardTitle>
          </CardHeader>
          <CardContent>
            {prediction ? (
              <div className="space-y-4" data-testid="prediction-result">
                <div className={cn(
                  "p-4 rounded-xl border-2 text-center",
                  prediction.status === "above"
                    ? "border-chart-2 bg-chart-2/10"
                    : prediction.status === "near"
                    ? "border-chart-3 bg-chart-3/10"
                    : "border-destructive bg-destructive/10"
                )}>
                  <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground mb-1">
                    Estimated Rank
                  </p>
                  <p className="text-3xl font-bold text-foreground" data-testid="result-rank">{prediction.estimatedRank}</p>
                  <Badge
                    className={cn(
                      "mt-2 text-xs",
                      prediction.status === "above"
                        ? "bg-chart-2/20 text-chart-2"
                        : prediction.status === "near"
                        ? "bg-chart-3/20 text-chart-3"
                        : "bg-destructive/20 text-destructive"
                    )}
                    variant="secondary"
                  >
                    {prediction.status === "above"
                      ? "Above cutoff"
                      : prediction.status === "near"
                      ? "Near cutoff"
                      : "Below cutoff"}
                  </Badge>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="p-3 rounded-lg bg-muted/50 text-center">
                    <p className="text-xs text-muted-foreground">Estimated Percentile</p>
                    <p className="text-xl font-bold text-foreground mt-1" data-testid="result-percentile">
                      {prediction.percentile.toFixed(2)}
                    </p>
                  </div>
                  <div className="p-3 rounded-lg bg-muted/50 text-center">
                    <p className="text-xs text-muted-foreground">2024 Cutoff %</p>
                    <p className="text-xl font-bold text-foreground mt-1">{prediction.cutoff2024}</p>
                  </div>
                </div>

                <div className="flex items-start gap-2 p-3 rounded-lg bg-accent/30 border border-accent-border">
                  <Info className="w-4 h-4 text-accent-foreground shrink-0 mt-0.5" />
                  <p className="text-xs text-muted-foreground">
                    This prediction is based on historical cutoff trends. Actual ranks depend on the
                    paper difficulty, number of candidates, and normalization.
                  </p>
                </div>
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center h-40 text-center">
                <Trophy className="w-10 h-10 text-muted-foreground/30 mb-3" />
                <p className="text-sm text-muted-foreground">Enter your percentage and click Predict</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Cutoff trend */}
      <Card className="border border-card-border shadow-sm">
        <CardHeader className="pb-2">
          <CardTitle className="text-base flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-primary" />
            {examType} Cutoff Trends
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2" data-testid="cutoff-history">
            {cutoffHistory.map((row) => (
              <div key={row.year} className="flex items-center gap-3">
                <span className="text-sm font-medium text-foreground w-12">{row.year}</span>
                <div className="flex-1 h-2.5 bg-muted rounded-full overflow-hidden">
                  <div
                    className="h-full bg-primary rounded-full"
                    style={{ width: `${row.cutoff}%` }}
                  />
                </div>
                <span className="text-sm font-mono text-muted-foreground w-10 text-right">{row.cutoff}%</span>
              </div>
            ))}
          </div>
          <p className="text-xs text-muted-foreground mt-4">
            * Cutoff percentages shown are general qualifying thresholds for general category.
          </p>
        </CardContent>
      </Card>

      {/* Subject-wise comparison to target */}
      {stats.length > 0 && (
        <Card className="border border-card-border shadow-sm">
          <CardHeader className="pb-2">
            <CardTitle className="text-base flex items-center gap-2">
              <Target className="w-4 h-4 text-primary" />
              Subject Gap Analysis
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <p className="text-xs text-muted-foreground">How far each subject is from the 70% strong threshold</p>
            {stats.map((s) => {
              const gap = Math.max(0, 70 - s.average);
              return (
                <div key={s.name} className="flex items-center gap-3" data-testid={`gap-${s.name.toLowerCase()}`}>
                  <span className="w-24 text-sm text-foreground font-medium shrink-0">{s.name}</span>
                  <div className="flex-1 h-2 bg-muted rounded-full overflow-hidden">
                    <div
                      className={cn("h-full rounded-full", s.average >= 70 ? "bg-chart-2" : "bg-chart-3")}
                      style={{ width: `${Math.min(100, s.average)}%` }}
                    />
                  </div>
                  <span className="text-xs text-muted-foreground w-20 text-right">
                    {gap === 0 ? "At target" : `${gap.toFixed(1)}% to go`}
                  </span>
                </div>
              );
            })}
          </CardContent>
        </Card>
      )}
    </div>
  );
}
