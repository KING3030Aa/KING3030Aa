import { pgTable, varchar, jsonb, timestamp } from "drizzle-orm/pg-core";
import { usersTable } from "./auth";

export const examsTable = pgTable("exams", {
  id: varchar("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => usersTable.id, { onDelete: "cascade" }),
  data: jsonb("data").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export type ExamRow = typeof examsTable.$inferSelect;
